const dropdown = document.getElementById('dropdown');

function showDropdown() {
  dropdown.classList.add('active');
}

function hideDropdown() {
  dropdown.classList.remove('active');
}